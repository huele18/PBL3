﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PBL3.GUI
{
    public partial class ucFood : UserControl
    {
        public ucFood()
        {
            InitializeComponent();
        }

        private void btSelect_Click(object sender, EventArgs e)
        {
            //if(addDataToGridViewDelegate != null)
            //{
            //    addDataToGridViewDelegate(lbNameFood.Text, lbPrice.Text);
            //}
            //if (fOrder.infoForm == null)
            //{
            //    fOrder.infoForm = new fOrder();
            //}
            //else 
            //GUI.fOrder.infoForm.addDataToGridViewDelegate(lbNameFood.Text, lbPrice.Text);


        }
    }
}
